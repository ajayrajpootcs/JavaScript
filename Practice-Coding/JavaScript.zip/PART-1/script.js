// let js='amazing';
// if(js === 'amazing') alert('JS is Amazing')
// let marksHeight = 1.68;
// let marksWeight=78;
// let johnsHeight=1.92;
// let johnsWeight=92;
// let marksBMI=marksWeight/(marksHeight**2);
// let johnsBMI=johnsWeight/(johnsHeight**2);
// console.log(marksBMI,johnsBMI);
// // let markHigherBMI=marksBMI>johnsBMI;
// // console.log(markHigherBMI);
// if(marksBMI>johnsBMI){
//     console.log(`Marks BMI(${marksBMI} is higher than john's BMI(${johnsBMI}))!`)
// }
// else{
//     console.log(`john's BMI(${marksBMI} is higher than Marks BMI (${johnsBMI}))!`)

// }
// let dolphilsScore=(97+112+101)/3;
// let KoalasScore=(109+95+123)/3;
// console.log(dolphilsScore, KoalasScore);
// if(dolphilsScore>KoalasScore && dolphilsScore>=100){
//     console.log('dolphils win!');
// }
// else if(dolphilsScore<KoalasScore && KoalasScore>=100){
//  console.log("koalas win!.")
// }
// else{
//     console.log("Both Win Draw match !")
// }
let bill=275;
// let Tip= bill>=50 && bill<=300 ?'Tip is 15%': 'Tip is 20%';
// console.log(Tip);
// console.log(`Tip is ${Tip= bill>=50 && bill<=300 ?'15%': '20%'}`);
console.log(`The bill was ${bill}, the tip was ${Tip= bill>=50 && bill<=300 ? (bill*15)/100:(bill*20)/100}, And The Total Value ${Tip+bill} `)